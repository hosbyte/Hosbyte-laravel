<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <!-- مسیر فایل CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <!-- CDN ها -->
    
    <link href="https://hosbyte.ir/files/bootstrap-5.3.7-dist/css/bootstrap.min.css" rel="stylesheet">    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">HOSBYTE</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link " href="<?php echo e(route('home')); ?>">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('portfolio')); ?>">نمونه کارها</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('certificates')); ?>">مدارک</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>">تماس با من</a>
                    </li>
                    
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    
                </div>
                <div class="col-md-6 text-start">
                    <div class="social-links">
                        
                        <a href="https://github.com/hosbyte" class="text-white me-3"><i
                                class="fab fa-github fa-lg"></i></a>
                        <a href="https://t.me/hosbyte" class="text-white me-3"><i class="fab fa-telegram fa-lg"></i></a>
                        <a href="https://instagram.com/hosbyte" class="text-white"><i
                                class="fab fa-instagram fa-lg"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- مسیر فایل JS -->
    

    <!-- CDN اسکریپت‌ها -->
    <script src="https://hosbyte.ir/files/bootstrap-5.3.7-dist/js/bootstrap.bundle.min.js"></script>
    
</body>

</html>
<?php /**PATH E:\app\xampp\htdocs\php\Hosbyte\resources\views\layout.blade.php ENDPATH**/ ?>