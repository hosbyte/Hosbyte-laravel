

<?php $__env->startSection('title', 'مدارک من'); ?>

<?php $__env->startSection('content'); ?>

    <body>
        <!-- بخش هیرو -->
        <section class="certificates-hero py-5 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center mb-5">
                        <h1 class="display-4 fw-bold">مدارک و گواهینامه‌ها</h1>
                        <p class="lead">مدارک و گواهینامه‌های کسب شده در زمینه تخصصی</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- بخش مدارک -->
        <section class="certificates-content py-5">
            <div class="container">
                <div class="row">
                    <!-- نمونه کارت مدرک -->
                    <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <?php if($certificate->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $certificate->image)); ?>" alt="<?php echo e($certificate->title); ?>"
                                        class="card-img-top">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($certificate->title); ?></h5>
                                    <p class="card-text"><?php echo e($certificate->description); ?></p>
                                    <p class="text-muted">تاریخ دریافت مدرک : <?php echo e($certificate->date); ?></p>
                                    <center>
                                        <a class="btn btn-primary" href="<?php echo e($certificate->certificate_url); ?>">مشاهده</a>
                                    </center>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\xampp\htdocs\php\Hosbyte\resources\views\Homes\certificates.blade.php ENDPATH**/ ?>