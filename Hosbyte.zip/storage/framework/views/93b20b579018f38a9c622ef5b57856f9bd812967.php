

<?php $__env->startSection('title', 'مدیریت مدارک - پنل مدیریت'); ?> --}}

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">مدیریت مدارک</h1>
        <a href="<?php echo e(route('admin.certificates.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>
            افزودن مدرک جدید
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <?php if($certificates->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th width="60">#</th>
                                <th width="100">تصویر</th>
                                <th>عنوان مدرک</th>
                                <th>مرجع صدور</th>
                                <th>تاریخ دریافت</th>
                                <th>وضعیت</th>
                                <th width="150">تاریخ ایجاد</th>
                                <th width="140">عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        
                                        <?php if($certificate->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $certificate->image)); ?>"
                                                alt="<?php echo e($certificate->title); ?>" class="rounded" width="50"
                                                height="50" style="object-fit: cover;">
                                        <?php else: ?>
                                            <div class="bg-light rounded d-flex align-items-center justify-content-center"
                                                style="width: 50px; height: 50px;">
                                                <i class="fas fa-certificate text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?php echo e($certificate->title); ?></strong>
                                        <?php if($certificate->duration): ?>
                                            <br>
                                            <small class="text-muted"><?php echo e($certificate->duration); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($certificate->issuer): ?>
                                            <span class="badge bg-info"><?php echo e($certificate->issuer); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small class="text-muted">
                                            <?php echo e(\Morilog\Jalali\Jalalian::fromCarbon($certificate->created_at)->format('Y/m/d')); ?>

                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check me-1"></i>
                                            فعال
                                        </span>
                                    </td>
                                    <td>
                                        <small class="text-muted">
                                            <?php echo e(\Morilog\Jalali\Jalalian::fromCarbon($certificate->created_at)->format('Y/m/d')); ?>

                                        </small>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="<?php echo e(route('admin.certificates.edit', $certificate->id)); ?>"
                                                class="btn btn-outline-warning" title="ویرایش">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('certificates')); ?>#certificate-<?php echo e($certificate->id); ?>"
                                                target="_blank" class="btn btn-outline-info" title="مشاهده در سایت">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <button type="button" class="btn btn-outline-danger" title="حذف"
                                                data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($certificate->id); ?>">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>

                                        <!-- Modal حذف -->
                                        <div class="modal fade" id="deleteModal<?php echo e($certificate->id); ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">تأیید حذف</h5>
                                                        <button type="button" class="btn-close"
                                                            data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>آیا از حذف مدرک "<strong><?php echo e($certificate->title); ?></strong>"
                                                            مطمئن هستید؟</p>
                                                        <p class="text-muted small">این عمل قابل بازگشت نیست.</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">انصراف</button>
                                                        <form
                                                            action="<?php echo e(route('admin.certificates.destroy', $certificate->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">
                                                                <i class="fas fa-trash me-1"></i>
                                                                حذف
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- صفحه‌بندی -->
                <?php if($certificates->hasPages()): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($certificates->links()); ?>

                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="mb-4">
                        <i class="fas fa-certificate fa-4x text-muted"></i>
                    </div>
                    <h4 class="text-muted">هنوز مدرکی اضافه نکرده‌اید</h4>
                    <p class="text-muted mb-4">می‌توانید اولین مدرک خود را اضافه کنید</p>
                    <a href="<?php echo e(route('admin.certificates.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>
                        افزودن مدرک جدید
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- آمار سریع -->
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($certificates->count()); ?></h4>
                            <p class="mb-0">کل مدارک</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-certificate fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($certificates->where('issuer', '!=', null)->count()); ?></h4>
                            <p class="mb-0">مدارک دارای مرجع</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-university fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?php echo e($certificates->where('certificate_url', '!=', null)->count()); ?></h4>
                            <p class="mb-0">مدارک دارای لینک</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-link fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\xampp\htdocs\php\Hosbyte\resources\views\admin\certificates\index.blade.php ENDPATH**/ ?>